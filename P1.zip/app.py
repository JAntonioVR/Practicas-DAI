# ./app/app.py

#
# ────────────────────────────────────────────────────────────
#   :::::: app.py : :  :   :    :     :        :          :
# ────────────────────────────────────────────────────────────
#
# Práctica 1 de DAI: Microframwork Flask
# Autor: Juan Antonio Villegas Recio
# Curso 2021-2022
# Universidad de Granada

# ─── IMPORTS ────────────────────────────────────────────────────────────────────
import math
import re
import random
from flask import Flask, render_template
app = Flask(__name__)


# ─── EJERCICIO 1 ────────────────────────────────────────────────────────────────

# Hello World   
@app.route('/')
def hello_world():
  return 'Hello, World!'

# Ejercicio 2: Ordenacion
# `lista` es una cadena de caracteres de numeros separados por espacios
# Por ejemplo: 5 2 7 3 10 9
@app.route('/ordena/<string:lista>')
def ordena(lista):
    lista = lista.split()
    map_object = map(int, lista)
    lista = list(map_object)
    lista_original = [i for i in lista]
    for num_pasada in range(len(lista)-1,0,-1):
        for i in range(num_pasada):
            if lista[i]>lista[i+1]:
                temp = lista[i]
                lista[i] = lista[i+1]
                lista[i+1] = temp
    return "Lista original: " + str(lista_original) + " Lista ordenada: " + str(lista)

# Ejercicio 3: Criba de Eratóstenes
@app.route('/criba/<int:n>')
def criba(n):
    lista = [i for i in range(2, n)]
    for i in range(2, int(math.sqrt(n))):
        for j in range(int(n/i)):
            if(i*j in lista):
                lista.remove(i*j)
    return str(lista)

# Ejercicio 4: Sucesión de Fibonacci
# Función que calcula el n-ésimo término de la sucesión de Fibonacci
def fibonacci(n):
    if(n == 0):
        return 0
    if(n == 1):
        return 1
    else:
        return fibonacci(n-1) + fibonacci(n-2)

@app.route('/fibonacci')
def fibonacci_from_file():
    f = open("./files/numero.txt", "r")
    n = int(f.read())
    f.close()
    res = fibonacci(n)
    f = open("./files/salida.txt", "w")
    f.write(str(res))
    f.close()
    return "El resultado es " + str(res) + " y está almacenado en files/salida.txt"

# Ejercicio 5: Corchetes
# Función que comprueba si la secuencia de corchetes está o no balanceada
def secuencia_balanceada(secuencia):
    balanceada = False
    cerrado_sin_abrir = False
    n_corchetes = 0
    for c in secuencia:
        if(c == "["):
            n_corchetes += 1
        else:
            n_corchetes -= 1

        if(n_corchetes < 0):
            balanceada = False
            cerrado_sin_abrir = True
        elif (n_corchetes == 0):
            balanceada = True
        else:
            balanceada = False
    if(balanceada and not cerrado_sin_abrir):
        return True
    else:
        return False

# Función que genera una secuencia aleatoria de corchetes de longitud `len`
def genera_secuencia(len):
    sec = ""
    for i in range(len):
        if(random.randint(0,2)):
            car = "["
        else:
            car = "]"
        sec += car
    return sec

@app.route('/corchetes/<int:longitud>')
def corchetes(longitud):
    sec = genera_secuencia(longitud)
    if(secuencia_balanceada(sec)):
        return "La secuencia " + sec + " está balanceada"
    else:
        return "La secuencia " + sec + " no está balanceada"

# Ejercicio 6: Verificar email
@app.route('/verifica_email/<string:email>')
def verifica_email(email):
    patron = "\w+@(hotmail|gmail|ugr|outlook)\.(com|es)"
    result = re.match(patron, email)
    if(result != None):
        return email + " es un correo electrónico"
    else:
        return email + " NO es un correo electrónico"


# ─── EJERCICIO 2 ────────────────────────────────────────────────────────────────

# Renderizar una página con una imagen
@app.route('/imagen')
def imagen():
    return render_template('imagen.html')


# ─── EJERCICIO 3 ────────────────────────────────────────────────────────────────

# Error 404
@app.errorhandler(404)
def page_not_found(error):
    return render_template('page_not_found.html'), 404
