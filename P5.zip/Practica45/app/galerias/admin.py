from django.contrib import admin

from .models import Galeria, Cuadro

admin.site.register(Galeria)
admin.site.register(Cuadro)

